const express = require('express')
const routers = express.Router()
const users = [{

    id:1 ,
    name:'Adriano',
    email:'adrianocesar01@gmail.com',
    password:'123456'
}]


routers.post('/login', (req, res) => {
    const {email, password} = req.body
    // res.send(email)
    const user = users.find(user=> user.email === email && user.password === password)
    if(user){
        res.status(200).json(user)
    }
    res.status(401).json({ MESSAGE: 'CREDENCIAL INVÁLIDA'})
})

module.exports = routers