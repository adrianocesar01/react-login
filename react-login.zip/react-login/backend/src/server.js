const express = require('express')

const routers = require('./routers')

const cors =  require('cors')
const app = express()

app.use(express.json())
app.use(cors())
app.use(routers)

app.get('/', (req, res) => {
    res.send("Hello World")
})

app.listen(8000, () =>{
    console.log("Executando na porta 8000")
})